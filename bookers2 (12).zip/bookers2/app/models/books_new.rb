class BooksNew < ApplicationRecord
end
