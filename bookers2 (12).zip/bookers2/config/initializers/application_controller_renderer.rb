# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'd47e04bf49f7f922c5f3c9dae2e6f45192100e41273b1c74a1aec2e965dd76522b763383ad61a7c161738bbcffb9581ef874628878c7de1ade445205396ed9d6'