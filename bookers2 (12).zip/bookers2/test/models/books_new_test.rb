require 'test_helper'

class BooksNewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
